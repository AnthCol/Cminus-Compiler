package absyn; 

abstract public class VarDec extends Dec
{
}